package com.kh.spring.member.model.service;

public interface MemberService {
}
