package com.kh.spring.admin.model.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.kh.spring.board.model.vo.Board;
import com.kh.spring.board.model.vo.PageInfo;

public interface AdminService {

	Board selectBoard(int boardNo, Integer cateNo);

	int getListCount(int cateNo); 

	ArrayList<Board> selectBoardList(PageInfo pi, int cateNo);

	int insertBoard(Board b);

	int updateBoard(Board b);

	int deleteBoard(int bId);

	int listSearchCount(HashMap<String, Object> map);

	ArrayList<Board> searchQuBoBoard(HashMap<String, Object> map, PageInfo pi);



}
