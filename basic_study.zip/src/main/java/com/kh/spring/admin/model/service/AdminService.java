package com.kh.spring.admin.model.service;

public interface AdminService {

}
