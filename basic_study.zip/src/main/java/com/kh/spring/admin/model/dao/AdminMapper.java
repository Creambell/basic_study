package com.kh.spring.admin.model.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AdminMapper {

}
