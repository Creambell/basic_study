package com.kh.spring.admin.model.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import com.kh.spring.board.model.vo.Board;
import com.kh.spring.member.model.vo.Member;

@Mapper
public interface AdminMapper {

	Board selectBoard(@Param("boardNo") int boardNo, @Param("cateNo") Integer cateNo);

	int getListCount(int cateNo);

	ArrayList<Board> selectBoardList(int cateNo, RowBounds rowBounds);

	int insertBoard(Board b);

	int updateBoard(Board b);

	int deleteBoard(int bId);

	int listSearchCount(HashMap<String, Object> map);

	ArrayList<Board> searchQuBoBoard(HashMap<String, Object> map, RowBounds rowBounds);

	ArrayList<Member> selectMember();
	
	int countMemberPost(int i);

	int countMemberReply(int i);
}
