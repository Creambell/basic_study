package com.kh.spring.admin.model.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.spring.admin.model.dao.AdminMapper;
import com.kh.spring.board.model.vo.Board;
import com.kh.spring.board.model.vo.PageInfo;
import com.kh.spring.member.model.vo.Member;

@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	private AdminMapper aMapper;

	@Override
    public Board selectBoard(int boardNo, Integer cateNo) {
        return aMapper.selectBoard(boardNo, cateNo);
    }
    
    @Override
    public int getListCount(int cateNo) {
        return aMapper.getListCount(cateNo);
    }
    
    @Override
    public ArrayList<Board> selectBoardList(PageInfo pi, int cateNo) {
        int offset = (pi.getCurrentPage() - 1) * pi.getBoardLimit();
        RowBounds rowBounds = new RowBounds(offset, pi.getBoardLimit());
        return aMapper.selectBoardList(cateNo, rowBounds);
    }
    
    @Override
    public int insertBoard(Board b) {
        return aMapper.insertBoard(b);
    }
    
    @Override
    public int updateBoard(Board b) {
        return aMapper.updateBoard(b);
    }

	@Override
	public int deleteBoard(int bId) {
		return aMapper.deleteBoard(bId);
	}

	@Override
	public int listSearchCount(HashMap<String, Object> map) {
		return aMapper.listSearchCount(map);
	}

	@Override
	public ArrayList<Board> searchQuBoBoard(HashMap<String, Object> map, PageInfo pi) {
	    int offset = (pi.getCurrentPage() - 1) * pi.getBoardLimit();
	    RowBounds rowBounds = new RowBounds(offset, pi.getBoardLimit());
	    return (ArrayList<Board>) aMapper.searchQuBoBoard(map, rowBounds);
	}
	
	@Override
	public ArrayList<Member> selectMember() {
		return aMapper.selectMember();
	}

	@Override
	public int countMemberPost(int i) {
		return aMapper.countMemberPost(i);
	}

	@Override
	public int countMemberReply(int i) {
		return aMapper.countMemberReply(i);
	}
}
