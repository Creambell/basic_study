package com.kh.spring.board.model.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {

}
